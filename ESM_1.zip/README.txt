Online Resource 1 (ESM_1) - replication package
Article: Interpretable and Fair Early Prediction of Student Dropout in Online Courses: Evidence from OULAD
Journal: Education and Information Technologies
Author: Sayed Athar Ali Hashmi, Department of Computer Science and Faculty of IT, Kalinga University, Raipur, Chhattisgarh, India
Corresponding author e-mail: [AUTHOR TO FILL]
Caption: Python scripts (01-04), result tables (including hyperparameter grids and selected values in out/table_models.csv), the day-30 feature table, and Figs. 1-6 as PNG and EPS.

Run order (seed 42): 01_inspect_and_aggregate.py -> 02_build_features.py -> 03_run_analysis.py -> 04_figures.py
Environment: Python 3.x, scikit-learn 1.8.0, pandas 3.0.2, numpy 2.4.4, matplotlib 3.10.8
Input: the 7 OULAD CSV files (CC BY 4.0; Kuzilek, Hlosta & Zdrahal, 2017, doi:10.1038/sdata.2017.171). Edit path U in scripts 01 and 02.
Code repository: [AUTHOR TO FILL]
